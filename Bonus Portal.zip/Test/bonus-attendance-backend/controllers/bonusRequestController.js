const BonusRequest = require('../models/BonusRequest');  // Updated to match the file name

// 🔹 Submit a new bonus request
const submitBonusRequest = async (req, res) => {
  try {
    const request = new BonusRequest(req.body);
    await request.save();
    res.status(201).json({ message: 'Bonus request submitted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error submitting request', error });
  }
};

// 🔹 Get requests for a specific student
const getStudentRequests = async (req, res) => {
  try {
    const studentId = req.params.studentId;
    const requests = await BonusRequest.find({ student: studentId });
    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching student requests', error });
  }
};

// 🔹 Get requests for a specific tutor email
const getTutorRequests = async (req, res) => {
  try {
    const tutorEmail = req.params.email;
    const requests = await BonusRequest.find({ tutorEmail });
    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching tutor requests', error });
  }
};

// 🔹 Update status and note by tutor
const updateTutorReview = async (req, res) => {
  try {
    const { status, tutorNote } = req.body;
    const updated = await BonusRequest.findByIdAndUpdate(
      req.params.id,
      { status, tutorNote },
      { new: true }
    );
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Error updating request', error });
  }
};

// 🔹 Get all requests (HOD view)
const getAllRequests = async (req, res) => {
  try {
    const allRequests = await BonusRequest.find();
    res.json(allRequests);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching all requests', error });
  }
};

// 🔹 Update status by HOD
const updateHODStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const updated = await BonusRequest.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: 'Error updating request', error });
  }
};

// 🔹 Get summary of approved requests
const getApprovedRequestsSummary = async (req, res) => {
  try {
    const summary = await BonusRequest.find({ status: 'accepted' }).select(
      'studentName studentEmail studentBranch studentSection studentRegNo'
    );
    res.json(summary);
  } catch (error) {
    res.status(500).json({ message: 'Error generating summary', error });
  }
};

module.exports = {
  submitBonusRequest,
  getStudentRequests,
  getTutorRequests,
  updateTutorReview,
  getAllRequests,
  updateHODStatus,
  getApprovedRequestsSummary
};
