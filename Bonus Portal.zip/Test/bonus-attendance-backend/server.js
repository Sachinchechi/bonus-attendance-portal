const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db'); // Import DB connection
require('dotenv').config();  // To use environment variables

// Import Routes
const studentRoutes = require('./routes/studentRoutes');
const tutorRoutes = require('./routes/tutorRoutes');
const hodRoutes = require('./routes/hodRoutes');
const bonusRequestRoutes = require('./routes/bonusRequestRoutes');


const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());  // To parse incoming JSON requests
app.use(cors());          // Enable CORS

// Routes
app.use('/api/student', studentRoutes);
app.use('/api/tutor', tutorRoutes);
app.use('/api/hod', hodRoutes);
 app.use('/api/bonus-request', bonusRequestRoutes);

// Default Route
app.get('/', (req, res) => {
  res.send('Welcome to the Bonus Attendance Portal API!');
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
