const mongoose = require('mongoose');

const bonusRequestSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
  dateFrom: { type: Date, required: true },
  dateTo: { type: Date, required: true },
  reason: { type: String, required: true },
  document: { type: String },
  status: { type: String, enum: ['pending', 'accepted', 'rejected'], default: 'pending' },
  tutorEmail: { type: String, required: true },
  tutorNote: { type: String, default: '' },
  reviewedByTutor: { type: Boolean, default: false }
}, { timestamps: true });

// ✅ This check prevents the OverwriteModelError:
module.exports = mongoose.models.BonusRequest || mongoose.model('BonusRequest', bonusRequestSchema);
