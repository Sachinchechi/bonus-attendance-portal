const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  registrationNumber: { type: String, required: true },
  branch: { type: String, required: true },
  section: { type: String, required: true },
  mobileNumber: { type: String, required: true },
  tutorName: { type: String, required: true },
  tutorEmail: { type: String, required: true },
  password: { type: String, required: true }, // auto-generated
}, { timestamps: true });

module.exports = mongoose.model('Student', studentSchema);
