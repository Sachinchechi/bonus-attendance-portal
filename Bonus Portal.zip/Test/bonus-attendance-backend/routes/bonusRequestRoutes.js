const express = require('express');
const router = express.Router();
const {
  submitBonusRequest,
  getStudentRequests,
  getTutorRequests,
  updateTutorReview,
  getAllRequests,
  updateHODStatus,
  getApprovedRequestsSummary
} = require('../controllers/bonusRequestController');

// 🔹 Student submits a bonus request
router.post('/submit', submitBonusRequest);

// 🔹 Get all requests made by a specific student
router.get('/student/:studentId', getStudentRequests);

// 🔹 Tutor views requests assigned to them
router.get('/tutor/:email', getTutorRequests);

// 🔹 Tutor updates request status + adds note
router.put('/update/:id', updateTutorReview);

// 🔹 HOD views all bonus requests
router.get('/all', getAllRequests);

// 🔹 HOD updates final status
router.put('/hod/update/:id', updateHODStatus);

// 🔹 HOD gets summary of approved requests
router.get('/summary', getApprovedRequestsSummary);

module.exports = router;
