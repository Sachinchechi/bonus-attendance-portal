const express = require('express');
const router = express.Router();
const Student = require('../models/Student');
const BonusRequest = require('../models/BonusRequest');
const bcrypt = require('bcrypt');

// Register student & auto-generate password
router.post('/register', async (req, res) => {
  try {
    const { name, email, registrationNumber, branch, section, mobileNumber, tutorName, tutorEmail } = req.body;

    const password = `${name.slice(0, 4)}${registrationNumber}${tutorName.slice(0, 3)}`.toLowerCase();
    const hashedPassword = await bcrypt.hash(password, 10);

    const student = new Student({
      name, email, registrationNumber, branch, section, mobileNumber,
      tutorName, tutorEmail,
      password: hashedPassword
    });

    await student.save();
    res.status(201).json({ message: 'Student registered successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Student Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const student = await Student.findOne({ email });

  if (!student) return res.status(401).json({ error: 'Invalid email or password' });

  const match = await bcrypt.compare(password.toLowerCase(), student.password);
  if (!match) return res.status(401).json({ error: 'Invalid email or password' });

  res.status(200).json({ message: 'Login successful', studentId: student._id });
});

// View Request Status
router.get('/requests/:studentId', async (req, res) => {
  const requests = await BonusRequest.find({ student: req.params.studentId });
  res.json(requests);
});

module.exports = router;
