const express = require('express');
const router = express.Router();
const HOD = require('../models/HOD');
const Tutor = require('../models/Tutor');
const BonusRequest = require('../models/BonusRequest');
const bcrypt = require('bcrypt');

// HOD login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const hod = await HOD.findOne({ email });
  if (!hod) return res.status(401).json({ error: 'Invalid email or password' });

  const match = await bcrypt.compare(password, hod.password);
  if (!match) return res.status(401).json({ error: 'Invalid email or password' });

  res.status(200).json({ message: 'Login successful' });
});

// Add new Tutor (only HOD can do this)
router.post('/add-tutor', async (req, res) => {
  const { email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);
  const newTutor = new Tutor({ email, password: hashedPassword });

  await newTutor.save();
  res.status(201).json({ message: 'Tutor created successfully' });
});

// Get all bonus requests grouped by tutor
router.get('/requests', async (req, res) => {
  const requests = await BonusRequest.find({});
  res.json(requests);
});

// Update request status
router.put('/requests/:id', async (req, res) => {
  const { status } = req.body;
  const updated = await BonusRequest.findByIdAndUpdate(req.params.id, { status }, { new: true });
  res.json(updated);
});

// Generate final summary list of approved requests
router.get('/summary', async (req, res) => {
  const approved = await BonusRequest.find({ status: 'Approved' });
  res.json(approved);
});

module.exports = router;
