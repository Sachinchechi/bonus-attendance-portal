const express = require('express');
const router = express.Router();
const Tutor = require('../models/Tutor');
const BonusRequest = require('../models/BonusRequest');
const bcrypt = require('bcrypt');

// Tutor login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const tutor = await Tutor.findOne({ email });
  if (!tutor) return res.status(401).json({ error: 'Invalid email or password' });

  const match = await bcrypt.compare(password, tutor.password);
  if (!match) return res.status(401).json({ error: 'Invalid email or password' });

  res.status(200).json({ message: 'Login successful', tutorId: tutor._id });
});

// Tutor views their own requests
router.get('/requests/:email', async (req, res) => {
  const requests = await BonusRequest.find({ tutorEmail: req.params.email });
  res.json(requests);
});

// Accept or Reject request
router.put('/requests/:id', async (req, res) => {
  const { status, tutorNote } = req.body;
  const request = await BonusRequest.findByIdAndUpdate(
    req.params.id,
    { status, tutorNote },
    { new: true }
  );
  res.json(request);
});

module.exports = router;
