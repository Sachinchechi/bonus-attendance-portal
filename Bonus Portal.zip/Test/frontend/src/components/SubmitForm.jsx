import React, { useState } from 'react';
import './form.css'; // optional if you plan to separate styles later

const SubmitForm = () => {
  const [formData, setFormData] = useState({
    studentName: '',
    email: '',
    registrationNumber: '',
    branch: '',
    section: '',
    mobile: '',
    dateFrom: '',
    dateTo: '',
    reason: '',
    tutorName: '',
    tutorEmail: '',
    document: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'document') {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic client-side validation
    if (!formData.tutorEmail || !formData.reason || !formData.dateFrom || !formData.dateTo) {
      alert('Please fill all the required fields before submitting.');
      return;
    }

    const data = new FormData();
    const studentId = '661c99f8a1b1cb3c174b02dc'; // Replace this with the dynamic student ID from your app state

    // Append required fields to FormData
    data.append('student', studentId); // Dynamically set student ID
    data.append('dateFrom', formData.dateFrom);
    data.append('dateTo', formData.dateTo);
    data.append('reason', formData.reason);
    data.append('tutorEmail', formData.tutorEmail);

    if (formData.document) {
      data.append('document', formData.document);
    }

    console.log('Form Data Submitted:', formData); // Add this for debugging
    try {
      const response = await fetch('http://localhost:5000/api/bonus-requests', {
        method: 'POST',
        body: data,
      });

      const result = await response.json();
      console.log('Server Response:', result);

      if (response.ok) {
        alert('Form submitted successfully!');
      } else {
        alert('Error: ' + (result.message || 'Submission failed'));
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('Something went wrong while submitting the form.');
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-white rounded-lg shadow-lg my-10">
      <h2 className="text-2xl font-bold mb-6 text-blue-700 text-center">Submit Bonus Attendance Request</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <input name="studentName" value={formData.studentName} onChange={handleChange} required placeholder="Student Name" className="input" />
          <input name="email" value={formData.email} onChange={handleChange} required placeholder="Email ID" className="input" />
          <input name="registrationNumber" value={formData.registrationNumber} onChange={handleChange} required placeholder="Registration Number" className="input" />
          <input name="branch" value={formData.branch} onChange={handleChange} required placeholder="Branch" className="input" />
          <input name="section" value={formData.section} onChange={handleChange} required placeholder="Section" className="input" />
          <input name="mobile" value={formData.mobile} onChange={handleChange} required placeholder="Mobile Number" className="input" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date From</label>
            <input type="date" name="dateFrom" value={formData.dateFrom} onChange={handleChange} required className="input" />
          </div>
          <div>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date To</label>
            <input type="date" name="dateTo" value={formData.dateTo} onChange={handleChange} required className="input" />
          </div>
        </div>

        <textarea name="reason" value={formData.reason} onChange={handleChange} required placeholder="Reason for Leave" className="input" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <input name="tutorName" value={formData.tutorName} onChange={handleChange} required placeholder="Tutor Name" className="input" />
          <input name="tutorEmail" value={formData.tutorEmail} onChange={handleChange} required placeholder="Tutor Email" className="input" />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">Attach Document</label>
          <input type="file" name="document" onChange={handleChange} className="input" />
        </div>

        <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md">
          Submit Request
        </button>
      </form>
    </div>
  );
};

export default SubmitForm;
