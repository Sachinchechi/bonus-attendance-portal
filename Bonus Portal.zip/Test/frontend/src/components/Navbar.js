import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <nav className="bg-gradient-to-r from-blue-800 to-blue-500 text-white py-4 px-6 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-3xl font-extrabold tracking-wide">
          Poornima Bonus Attendance Portal
        </Link>
        <div className="space-x-6 relative">
          <Link
            to="/form"
            className="hover:bg-blue-700 py-2 px-4 rounded-md transition-all duration-200"
          >
            Submit Bonus Request
          </Link>

          {/* Dropdown Menu */}
          <div
            className="relative inline-block text-left"
            onMouseEnter={() => setDropdownOpen(true)}
            onMouseLeave={() => setDropdownOpen(false)}
          >
            <button className="bg-white text-blue-800 hover:text-white hover:bg-blue-700 py-2 px-4 rounded-md transition-all duration-200">
              Login
            </button>
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white text-gray-800 rounded-md shadow-lg py-2 z-50">
                <Link
                  to="/login/student"
                  className="block px-4 py-2 hover:bg-blue-100"
                >
                  Student Login
                </Link>
                <Link
                  to="/login/tutor"
                  className="block px-4 py-2 hover:bg-blue-100"
                >
                  Tutor Login
                </Link>
                <Link
                  to="/login/hod"
                  className="block px-4 py-2 hover:bg-blue-100"
                >
                  HOD Login
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
