import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import BonusForm from './pages/BonusForm';
import Navbar from './components/Navbar';
import StudentLogin from './pages/StudentLogin';
import TutorLogin from './pages/TutorLogin';
import HODLogin from './pages/HODLogin';
import StudentDashboard from './pages/StudentDashboard';
import TutorDashboard from './pages/TutorDashboard';
import HodDashboard from './pages/HodDashboard';
import { UserProvider } from './context/UserContext'; // ✅ Import context
import './App.css';

function App() {
  return (
    <UserProvider> {/* ✅ Wrap everything inside UserProvider */}
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/form" element={<BonusForm />} />
          <Route path="/login/student" element={<StudentLogin />} />
          <Route path="/login/tutor" element={<TutorLogin />} />
          <Route path="/login/hod" element={<HODLogin />} />
          <Route path="/student/dashboard" element={<StudentDashboard />} />
          <Route path="/tutor/dashboard" element={<TutorDashboard />} />
          <Route path="/hod/dashboard" element={<HodDashboard />} />
        </Routes>
      </Router>
    </UserProvider>
  );
}

export default App;
