import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TutorDashboard = () => {
  const [email, setEmail] = useState('');
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchRequests = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/bonus-request/tutor/${email}`);
      setRequests(res.data);
    } catch (error) {
      console.error('Error fetching tutor requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (id, status, note) => {
    try {
      await axios.put(`http://localhost:5000/api/bonus-request/update/${id}`, {
        status,
        tutorNote: note,
      });
      alert('Request updated successfully!');
      fetchRequests(); // refresh the list
    } catch (error) {
      console.error('Error updating request:', error);
    }
  };

  useEffect(() => {
    if (email) {
      fetchRequests();
    }
  }, [email]);

  return (
    <div style={{ padding: '20px' }}>
      <h2>📋 Tutor Dashboard</h2>

      {/* TEMP EMAIL INPUT */}
      <input
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ padding: '8px', width: '300px', marginBottom: '20px' }}
      />

      {loading ? (
        <p>Loading...</p>
      ) : (
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Program</th>
              <th>Activity</th>
              <th>Date</th>
              <th>Status</th>
              <th>Note</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((req) => (
              <tr key={req._id}>
                <td>{req.programName}</td>
                <td>{req.activityName}</td>
                <td>{req.activityDate?.from} → {req.activityDate?.to}</td>
                <td>{req.status}</td>
                <td>{req.tutorNote || '-'}</td>
                <td>
                  <button
                    onClick={() => {
                      const note = prompt("Enter approval note:");
                      if (note) handleUpdate(req._id, 'approved', note);
                    }}
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => {
                      const note = prompt("Enter rejection reason:");
                      if (note) handleUpdate(req._id, 'rejected', note);
                    }}
                    style={{ marginLeft: '10px', color: 'red' }}
                  >
                    Reject
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default TutorDashboard;
