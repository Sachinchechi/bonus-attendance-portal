import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StudentDashboard = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [studentId, setStudentId] = useState(''); // You’ll update this with real data

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        // Replace this with actual ObjectId from login
        const res = await axios.get(`http://localhost:5000/api/bonus-request/student/${studentId}`);
        setRequests(res.data);
      } catch (err) {
        console.error('Error fetching requests:', err);
      } finally {
        setLoading(false);
      }
    };

    if (studentId) {
      fetchRequests();
    }
  }, [studentId]);

  return (
    <div style={{ padding: '20px' }}>
      <h2>🎓 Student Dashboard</h2>

      {/* Temporary input for student ID */}
      <input
        type="text"
        placeholder="Enter your Student ObjectId"
        value={studentId}
        onChange={(e) => setStudentId(e.target.value)}
        style={{ padding: '8px', width: '300px', marginBottom: '20px' }}
      />

      {loading ? (
        <p>Loading requests...</p>
      ) : (
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Program</th>
              <th>Activity</th>
              <th>From</th>
              <th>To</th>
              <th>Status</th>
              <th>Tutor Note</th>
              <th>Final Status (HOD)</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((req) => (
              <tr key={req._id}>
                <td>{req.programName}</td>
                <td>{req.activityName}</td>
                <td>{req.activityDate?.from}</td>
                <td>{req.activityDate?.to}</td>
                <td>{req.status}</td>
                <td>{req.tutorNote}</td>
                <td>{req.hodStatus}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default StudentDashboard;
