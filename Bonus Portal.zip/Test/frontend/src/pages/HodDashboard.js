import React, { useEffect, useState } from 'react';
import axios from 'axios';

const HodDashboard = () => {
  const [requests, setRequests] = useState([]);
  const [summary, setSummary] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAllRequests = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/bonus-request/all');
      setRequests(res.data);
    } catch (err) {
      console.error('Error fetching requests:', err);
    }
  };

  const fetchSummary = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/bonus-request/summary');
      setSummary(res.data);
    } catch (err) {
      console.error('Error fetching summary:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFinalDecision = async (id, status) => {
    try {
      await axios.put(`http://localhost:5000/api/bonus-request/hod/update/${id}`, {
        finalStatus: status
      });
      alert(`Request ${status === 'approved' ? 'Approved' : 'Rejected'} by HOD`);
      fetchAllRequests();
      fetchSummary();
    } catch (err) {
      console.error('Error updating status:', err);
    }
  };

  useEffect(() => {
    fetchAllRequests();
    fetchSummary();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>📊 HOD Dashboard</h2>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          <h3>🗃️ All Bonus Attendance Requests</h3>
          <table border="1" cellPadding="10">
            <thead>
              <tr>
                <th>Student</th>
                <th>Program</th>
                <th>Activity</th>
                <th>Tutor Status</th>
                <th>Tutor Note</th>
                <th>Final Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((req) => (
                <tr key={req._id}>
                  <td>{req.student?.name || 'N/A'}</td>
                  <td>{req.programName}</td>
                  <td>{req.activityName}</td>
                  <td>{req.status}</td>
                  <td>{req.tutorNote || '-'}</td>
                  <td>{req.finalStatus || '-'}</td>
                  <td>
                    <button
                      onClick={() => handleFinalDecision(req._id, 'approved')}
                      style={{ marginRight: '10px' }}
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleFinalDecision(req._id, 'rejected')}
                      style={{ color: 'red' }}
                    >
                      Reject
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3 style={{ marginTop: '40px' }}>📈 Approved Requests Summary</h3>
          <ul>
            {summary.map((item, index) => (
              <li key={index}>
                <strong>{item.student?.name}</strong> – {item.activityName} ({item.programName})
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default HodDashboard;
