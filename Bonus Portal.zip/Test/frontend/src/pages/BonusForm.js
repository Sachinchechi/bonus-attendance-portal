import React, { useState } from 'react';
import API from '../api/axios'; // ✅ Make sure this path is correct!

function BonusForm() {
  const [formData, setFormData] = useState({
    studentName: '',
    email: '',
    registrationNumber: '',
    branch: '',
    section: '',
    mobileNumber: '',
    dateFrom: '',
    dateTo: '',
    reason: '',
    tutorName: '',
    tutorEmail: '',
    file: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, file: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const payload = new FormData();

      payload.append('student', FormData.studentName);            // required ✅
payload.append('tutorEmail', FormData.tutorEmail);          // required ✅
payload.append('dateFrom', FormData.dateFrom);              // required ✅
payload.append('dateTo', FormData.dateTo);                  // required ✅
payload.append('reason', formData.reason);                  // required ✅

payload.append('email', FormData.email);
payload.append('registrationNumber', FormData.registrationNumber);
payload.append('branch', FormData.branch);
payload.append('section', FormData.section);
payload.append('mobileNumber', FormData.mobileNumber);
payload.append('tutorName', FormData.tutorName);

      if (formData.file) {
        payload.append('file', FormData.file);
      }

      const res = await API.post('/bonus-request/submit', payload, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      alert(res.data.message || 'Request submitted successfully!');

      setFormData({
        studentName: '',
        email: '',
        registrationNumber: '',
        branch: '',
        section: '',
        mobileNumber: '',
        dateFrom: '',
        dateTo: '',
        reason: '',
        tutorName: '',
        tutorEmail: '',
        file: null,
      });
    } catch (err) {
      console.error('Submission failed:', err);
      alert('Submission failed. Please try again.');
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen flex items-center justify-center">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-lg">
        <h2 className="text-2xl font-bold text-center mb-6 text-blue-600">
          Submit Bonus Attendance Request
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-700">Student Information</h3>

          <div>
            <label htmlFor="studentName" className="block text-gray-700 font-medium">
              Student Name:
            </label>
            <input
              type="text"
              id="studentName"
              name="studentName"
              value={formData.studentName}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="email" className="block text-gray-700 font-medium">
              Student Email:
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., 2021pietcsabc123@poornima.org"
            />
          </div>

          <div>
            <label htmlFor="registrationNumber" className="block text-gray-700 font-medium">
              Registration Number:
            </label>
            <input
              type="text"
              id="registrationNumber"
              name="registrationNumber"
              value={formData.registrationNumber}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="branch" className="block text-gray-700 font-medium">
              Branch:
            </label>
            <input
              type="text"
              id="branch"
              name="branch"
              value={formData.branch}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="section" className="block text-gray-700 font-medium">
              Section:
            </label>
            <input
              type="text"
              id="section"
              name="section"
              value={formData.section}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="mobileNumber" className="block text-gray-700 font-medium">
              Mobile Number:
            </label>
            <input
              type="tel"
              id="mobileNumber"
              name="mobileNumber"
              value={formData.mobileNumber}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Leave Details Section */}
          <h3 className="text-lg font-semibold text-gray-700">Leave Details</h3>

          <div>
            <label htmlFor="dateFrom" className="block text-gray-700 font-medium">
              Leave From:
            </label>
            <input
              type="date"
              id="dateFrom"
              name="dateFrom"
              value={FormData.dateFrom}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="dateTo" className="block text-gray-700 font-medium">
              Leave To:
            </label>
            <input
              type="date"
              id="dateTo"
              name="dateTo"
              value={FormData.dateTo}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="reason" className="block text-gray-700 font-medium">
              Reason for Leave:
            </label>
            <textarea
              id="reason"
              name="reason"
              value={formData.reason}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="tutorName" className="block text-gray-700 font-medium">
              Tutor Name:
            </label>
            <input
              type="text"
              id="tutorName"
              name="tutorName"
              value={formData.tutorName}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="tutorEmail" className="block text-gray-700 font-medium">
              Tutor Email:
            </label>
            <input
              type="email"
              id="tutorEmail"
              name="tutorEmail"
              value={formData.tutorEmail}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="file" className="block text-gray-700 font-medium">
              Attach Document:
            </label>
            <input
              type="file"
              id="file"
              name="file"
              onChange={handleFileChange}
              required
              className="w-full border border-gray-300 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded transition duration-300"
          >
            Submit Request
          </button>
        </form>
      </div>
    </div>
  );
}

export default BonusForm;
