import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="h-screen bg-cover bg-center bg-no-repeat flex flex-col items-center justify-center text-white"
         style={{ backgroundImage: "url('https://source.unsplash.com/1600x900/?college,classroom')" }}>
      <div className="bg-white p-10 rounded-lg shadow-2xl text-center space-y-6">
        <h1 className="text-4xl font-bold text-blue-600">
          Welcome to Poornima Bonus Attendance Portal
        </h1>
        <p className="text-lg text-gray-700">
        

        <br></br>
        
        </p>
        <Link
          to="/form"
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
        >
          Submit Bonus Request
        </Link>
      </div>

      {/* Login Portals Section */}
      <div className="mt-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Login Portals</h2>
        <div className="flex space-x-6">
          {/* Student Login */}
          <Link to="/login/student">
            <button className="bg-gray-100 text-black px-4 py-2 rounded hover:bg-gray-300 transition-all">
              Student Login
            </button>
          </Link>

          {/* Tutor Login */}
          <Link to="/login/tutor">
            <button className="bg-gray-100 text-black px-4 py-2 rounded hover:bg-gray-300 transition-all">
              Tutor Login
            </button>
          </Link>

          {/* HOD Login */}
          <Link to="/login/hod">
            <button className="bg-gray-100 text-black px-4 py-2 rounded hover:bg-gray-300 transition-all">
              HOD Login
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
