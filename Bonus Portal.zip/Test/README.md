# bonus-attendance-portal
this project is web portal to apply for bonus attendance in the college , if you were absent for some days for a valid reason 
